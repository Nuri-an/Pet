<?php

$lista = array();     //A var lista é declarada como um array
$i = 0;
$conn=mysqli_connect("localhost","root","","nomedoBD");   //Conecção com o BD
$buscaDados = mysqli_query($conn,"SELECT ...");          //Busca dos dados no BD
    
    while ($recebeDados = mysqli_fetch_array($buscaDados)) {  

        $lista[$i] = $recebeDados['item'];     //O array lista em uma determinada posição recebe o item desta
        $quant = $recebeDados['quant'];      //Valor da quantidade de itens da lista
        $i++;
    }

    for($j = 0; $j < $quant; $j++){

        $lista[$j] = $lista[$j+1];
    }

?>