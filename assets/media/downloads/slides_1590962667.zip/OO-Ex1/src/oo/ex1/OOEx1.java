/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oo.ex1;

import Classes.Cliente;
import java.util.Scanner;

/**
 *
 * @author Nuian
 */
public class OOEx1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Cliente c;
        c = new Cliente();
        
        Scanner digita = new Scanner(System.in); //responsavel para ler o que é digitado no teclado, "cin"
        
        System.out.println("Digite as informacooes do cliente:");
        System.out.println("Nome:");
        c.setNome(digita.next());
        System.out.println("CPF:");
        c.setCpf(digita.nextLong());
        System.out.println("Idade:");
        c.setIdade(digita.nextInt());
        System.out.println("Sexo:");
        c.setSexo(digita.next());
        System.out.println("Altura:");
        c.setAltura(digita.nextFloat());
        System.out.println("Peso:");
        c.setPeso(digita.nextFloat());
        System.out.println("Endereco:");
        c.setEndereco(digita.next());
        
        c.imprimeDados();
        
    }
    
}
